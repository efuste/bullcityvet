	<div class="footer clearfix">
			<p class="copyright">&copy; Bull City Veterinary Hospital</p><!-- /.copyright -->

			<div class="site-links clearfix">
				<a href="sitemap.php">Site Map</a>
				<a href="contact.php">Contact</a>
				
			</div><!-- /.site-links -->
			<span class="bg-middle"></span>
		</div><!-- /.footer -->
	</div><!-- /.shell -->	

	<span class="bg-left"></span>
	<span class="bg-right"></span>
</div><!-- /.page-holder -->
</body>
</html>