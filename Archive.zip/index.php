<?php include('header.php'); ?>

		<div class="container">
			<div class="bannercontainer">
				<div class="banner">
			
				<ul>
					<li data-transition="fade" data-masterspeed="1000" >
					<!-- MAIN IMAGE -->
					<img src="css/images/slide_our_office.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
					<!-- LAYERS -->
					<div class="tp-caption medium_bg_darkcyan skewfromrightshort customout"
						data-x="right" data-hoffset="-50"
						data-y="top" data-voffset="30"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1700"
						data-easing="Back.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on"
						style="z-index: 4">Bull City Veterinary Hospital 
					</div>
					<!-- LAYER NR. 1 -->
					<div class="tp-caption medium_bg_darkcyan skewfromrightshort customout"
						data-x="right" data-hoffset="-70"
						data-y="top" data-voffset="100"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1800"
						data-easing="Back.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on"
						style="z-index: 4">Opening January 2014!
					</div>
					<!-- LAYER NR. 2 -->
					<div class="tp-caption customin customout"
						data-x="left" data-hoffset="160"
						data-y="top" data-voffset="30"
						data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="800"
						data-start="1100"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						style="z-index: 20"><img src="css/images/city_buildings_1.png" alt="">
					</div>
					
					<div class="tp-caption customin customout"
						data-x="left" data-hoffset="5"
						data-y="top" data-voffset="5"
						data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="800"
						data-start="1400"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						style="z-index: 3"><img src="css/images/city_building2.png" alt="">
					</div>
					
				</li>
				<!-- SLIDE  -->
				<li data-transition="fade" data-slotamount="7" data-masterspeed="1000" >
					<!-- MAIN IMAGE -->
					<img src="css/images/slide_special_discount1.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
					<!-- LAYERS -->
					
					<!-- LAYERS -->
					<div class="tp-caption medium_bg_darkcyan skewfromrightshort customout"
						data-x="right" data-hoffset="-15"
						data-y="top" data-voffset="30"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1100"
						data-easing="Back.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on"
						style="z-index: 4">A Gift For New Clients
					</div>
					<!-- LAYER NR. 1 -->
					<div class="tp-caption medium_thin_darkcyan  skewfromrightshort customout"
						data-x="right" data-hoffset="-95"
						data-y="top" data-voffset="100"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1100"
						data-easing="Back.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on"
						style="z-index: 4">Bull City Veterinary Hospital is  <br /> offering   a 20% discount on<br /> your pets first exam, limited to <br />new clients
					</div>
					
					
				</li>
				<!-- SLIDE  -->
				<li data-transition="fade" data-masterspeed="1000" >
					<!-- MAIN IMAGE -->
					<img src="css/images/slide_special_2.jpg" style='background-color:#b2c4cc' alt=""  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
					<!-- LAYERS -->
					<!-- LAYERS -->
					<div class="tp-caption medium_bg_darkcyan skewfromrightshort customout"
						data-x="right" data-hoffset="-15"
						data-y="top" data-voffset="30"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1100"
						data-easing="Back.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on"
						style="z-index: 4">Why Not A Second Discount?
					</div>
					<!-- LAYER NR. 1 -->
					<div class="tp-caption medium_thin_white skewfromrightshort customout"
						data-x="right" data-hoffset="-80"
						data-y="top" data-voffset="100"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1100"
						data-easing="Back.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on"
						style="z-index: 4">Bull City Veterinary Hospital is also offering<br /> a free  physical exam on any recently<br /> adopted pet(s) from any of the local  shelters<br /> or rescue organizations.
					</div>
					
					
					
				</li>
				
					
					

					
				</ul>
			</div><!-- /.slider -->
		</div>
			<div class="main home">
				<div class="content">
					<div class="entry">
						<h2>Welcome to Bull City Veterinary Hospital</h2>

						<p>
							We are proud to introduce one of the 1st Veterinary Hospitals to the Downtown Durham area.Our goal is 
							to provide excellent veterinary care and exceptional customer service to the local community. Our 
							state of the art equipment and trained staff will facilitate our  goal. We emphasize the importance
						    of continuing education  to stay up to date with the latest studies and technology to be able to offer the 
						    best possible care to our patients .
							We are very excited to serve the local community  and to be a part of local upcoming events.
						</p>
					</div><!-- /.entry -->

					<div class="boxes clearfix">
						<div class="box box1 service">
							<h3>Acupuncture</h3>

							<div class="box-content">
								<p>Acupuncture is the insertion of dry needles into the skin at speciﬁc points known as acupuncture 
									points. It is a form of medicine which originated in China over 2,500 years ago. In Traditional 
									Chinese Veterinary Medicine, it can be used as a sole means of treatment for any most 
									diseases or health issues or it can be used as a complementary form of treatment with other 
									types of medicine.
								</p>
							</div><!-- /.box-content -->
							
							<p class="buttons"><a href="#" class="more">Learn More &gt;</a></p><!-- /.buttons -->
						</div><!-- /.box box1 -->

						<div class="box box1 service">
							<h3>Tui Na</h3>

							<div class="box-content">
								<p>Tui na is a form of Chinese hand manipulation that is most often used in conjunction with 
									acupuncture to achieve balance in a patient. It has some similarities to chiropractic work and 
									massage therapy, but it's general purpose is to resolve disease states.
								</p>
							</div><!-- /.box-content -->
							
							<p class="buttons"><a href="#" class="more">Learn More &gt;</a></p><!-- /.buttons -->
						</div><!-- /.box box1 -->

						<div class="box box1 service">
							<h3>Therapeutic Laser</h3>

							<div class="box-content">
								<p>Therapeutic laser uses the energy of light to achieve cellular metabolic changes in the treatment 
									of a variety of conditions. Class IV therapy lasers can be used in a variety of issues including 
									the alleviation of the pain of arthritis, improving circulation, promoting wound and incision 
									healing and decreasing inﬂammation.
								</p>
							</div><!-- /.box-content -->
							
							<p class="buttons"><a href="#" class="more">Learn More &gt;</a></p><!-- /.buttons -->
						</div><!-- /.box box1 -->
					</div><!-- /.boxes -->

					
		</div><!-- /.container -->
		<div class="content-bottom clearfix">
						<div class="newsletter-form">
							<h4>Schedule Appointment</h4>
							 <form action="formsubmit_newsletter.php" method="post">
            					<fieldset id="contact">
              					<input name="name" type="text" class="forms" id="name" size="35" placeholder="Name" required/>
              				    <input name="petname" type="text" class="forms" id="petname" size="35" placeholder="Pet Name" required/>
              					<input name="phone" type="phone" class="forms" id="phone" size="35" placeholder="Phone" required/>

              					<input name="date" type="date" class="forms" id="date" size="35" value="Date" required/>
              				    <input name="time" type="time" class="forms" id="time" size="35" value="Email" required/>
              					<textarea name="message" cols="30" rows="4" class="forms" id="message">Enter Message</textarea>
              
              					<input name="submit_message" type="submit" id="submit_message" class="submit_button" value="Submit" />
            					</fieldset>
          					</form>
							</div><!-- /.newsletter-form -->

						<div class="quotes">
							<h2>Testimonials</h2>
							<div class="quote">
								<blockquote>
									Dr. Sabin has greatly enhanced the quality of life for CoCo, our 16 year-old Chow/
									German Shepherd mix. Dr. Sabin has provided 
									mobile veterinary care for CoCo in our home for over 2 years. She alternates acupuncture treatments 
									and laser therapy for CoCo on a weekly basis. The treatments are so soothing and relaxing to CoCo that 
									she actually falls asleep and appears disappointed when they are completed. All of our experiences with 
									Dr. Sabin demonstrate that she is a skillful, caring, accessible, and flexible vet; and just a wonderful and 
									compassionate human being! 
								</blockquote>
							</div>	
							<div class="quote">
								
								<blockquote>
									Dr. Sabin's knowledge and compassion for animals is apparent. My husband and I always have a 
									pleasant experience with her and her staff members. She explains things to us in simple terms and we 
									never feel rushed during the appointment time (we really appreciate that). We recommend her to anyone that's looking for an 
									exceptional veterinarian with extensive knowledge, AMAZING! Acupuncture skills, great personality and 
									above all, honesty. "Jack" and "Bailey" can't thank you enough for all the care, love and compassion you have given them 
									for the past 4 years.


								</blockquote>
							</div><!-- /.quote -->
						</div><!-- /.quotes -->
					</div><!-- /.content-bottom -->
       
  	
<?php include('footer.php'); ?>
